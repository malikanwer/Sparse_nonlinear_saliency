%%%%%%%%%%%%%%%%Main Program%%%%%%%%%%%%%%%%%%%%%
clear all;close all;clc
%%Add Two packages to the path  

%%http://web.cs.hacettepe.edu.tr/~erkut/projects/CovSal/saliency.zip
%%Erdem, Erkut, and Aykut Erdem. "Visual saliency estimation by nonlinearly integrating
%%features using region covariances." Journal of vision 13.4 (2013): 11.

addpath('C:\Users\Shahzad\Desktop\Code\erdem');         %% Path in my Computer

%%Fast ICA is available at
%%http://research.ics.aalto.fi/ica/fastica/code/dlcode.shtml
%%Version tested :FastICA 2.5 for Matlab 7.x and Matlab 6.x

addpath('C:\Users\Shahzad\Desktop\Code\FastICA_2.5');  %% Path in my Computer
%%%%%%%

I=imread('10.jpg');

%%% Scale of Output Image will be equal to the Input Image
%%% Default fix Parameters are set in the saliency map generation as mentioned in
%%% the paper
finalMap=saliency_map('10.jpg');

%%Output Saliency Map
imshow(finalMap)


